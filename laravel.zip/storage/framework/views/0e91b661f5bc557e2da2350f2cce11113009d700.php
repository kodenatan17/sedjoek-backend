<a href="/">
   <img src ="/logo.svg" alt="Logo" />
</a>
<?php /**PATH /home/kodenatan/Projects/sedjoek_backend/resources/views/vendor/jetstream/components/authentication-card-logo.blade.php ENDPATH**/ ?>